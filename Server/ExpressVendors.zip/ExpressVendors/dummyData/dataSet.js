module.exports = [
    vendors = [
        {'name':'Asia Tools PVT LTD', 'image':'https://mdbootstrap.com/img/Photos/Others/images/16.jpg', 'country': 'China','items':['A','B']},
        {'name':'Alibaba Constructions', 'image':'https://mdbootstrap.com/img/Photos/Others/images/16.jpg','country': 'Sri Lanka','items':['D','B']},
        {'name':'Asia Metals Industries', 'image':'https://mdbootstrap.com/img/Photos/Others/images/16.jpg', 'country': 'India','items':['E','B']},
        {'name':'Lanwa SL', 'image':'https://mdbootstrap.com/img/Photos/Others/images/16.jpg', 'country': 'Japan','items':['A','C']}
    ]
    ,
    itemList =[
            { "id": "tt0110357", "name": "The Lion King", "genre": "animation"},
            { "id": "tt0068646", "name": "The Godfather", "genre": "crime"},
            { "id": "tt0468569", "name": "The Dark Knight", "genre": "action"}
     ]
];